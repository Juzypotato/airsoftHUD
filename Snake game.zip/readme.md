A snake nevű játékot hoztam létre arduino segítségével, amit lehet egy akkumlátorról el lehet látni, így hordozható.

Futtatás után a játékot el lehet indítani akármely gomb megnyomásávál.
A kígyó alapból balról jobbra néz.
A játék célja, hogy minél több gyümölcsöt gyűjtsünk össze, amiket random helyezek el.
Minden megevett gyümölcsel a kígyó egyel hosszabb lesz.
A játék akkor ér véget, ha az egyik falnak vagy saját magának ütközik a kígyó, ekkor kiírja, hogy "Gameover".
Akármelyik gomb megnyomásával visszaállíthatjuk a játékot a kezdő értékekre, majd megint egy gombnyomással indíthatjuk a játékot.